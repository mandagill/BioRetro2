class OAuth2Error(Exception):
    pass


class ConfigurationError(OAuth2Error):
    pass
